/* =========================================
   DEALPILOT — JavaScript Application
   ========================================= */

// ========== STATE MANAGEMENT ==========
let state = {
  projects: {},
  activeProject: null,
  rates: null, // { base: 'EUR', rates: { USD: 1.08, ... }, fetchedAt: timestamp }
  activeTab: 'overview'
};

// ========== CONSTANTS ==========
const CURRENCIES = ['EUR','USD','MAD','GBP','CHF','CAD','JPY','AED','AUD','SEK','NOK','DKK','PLN','CZK','HUF','TRY','ZAR','BRL','MXN','CNY','INR','KRW','THB','IDR','MYR','PHP','SGD','HKD','TWD','NZD'];
const CATEGORY_COLORS = ['#D4AF37','#22C55E','#F59E0B','#EF4444','#8B5CF6','#06B6D4','#84CC16','#F97316'];

const COUNTRIES_DATA = {
  'FR': { name: 'France', currency: 'EUR', flag: '🇫🇷', cities: ['Paris', 'Lyon', 'Marseille', 'Toulouse', 'Nice', 'Nantes', 'Strasbourg', 'Montpellier', 'Bordeaux', 'Lille'] },
  'MA': { name: 'Morocco', currency: 'MAD', flag: '🇲🇦', cities: ['Marrakech', 'Casablanca', 'Rabat', 'Fès', 'Tangier', 'Agadir', 'Meknès', 'Oujda', 'Tétouan', 'Essaouira'] },
  'US': { name: 'United States', currency: 'USD', flag: '🇺🇸', cities: ['New York', 'Los Angeles', 'Chicago', 'Houston', 'Phoenix', 'Philadelphia', 'San Antonio', 'San Diego', 'Dallas', 'San Francisco'] },
  'GB': { name: 'United Kingdom', currency: 'GBP', flag: '🇬🇧', cities: ['London', 'Birmingham', 'Manchester', 'Glasgow', 'Liverpool', 'Leeds', 'Sheffield', 'Edinburgh', 'Bristol', 'Cardiff'] },
  'CH': { name: 'Switzerland', currency: 'CHF', flag: '🇨🇭', cities: ['Zurich', 'Geneva', 'Basel', 'Bern', 'Lausanne', 'Winterthur', 'Lucerne', 'St. Gallen', 'Lugano', 'Thun'] },
  'CA': { name: 'Canada', currency: 'CAD', flag: '🇨🇦', cities: ['Toronto', 'Montreal', 'Vancouver', 'Calgary', 'Ottawa', 'Edmonton', 'Winnipeg', 'Quebec City', 'Hamilton', 'Halifax'] },
  'JP': { name: 'Japan', currency: 'JPY', flag: '🇯🇵', cities: ['Tokyo', 'Osaka', 'Yokohama', 'Nagoya', 'Sapporo', 'Fukuoka', 'Kobe', 'Kyoto', 'Hiroshima', 'Sendai'] },
  'AE': { name: 'UAE', currency: 'AED', flag: '🇦🇪', cities: ['Dubai', 'Abu Dhabi', 'Sharjah', 'Al Ain', 'Ajman', 'Ras al-Khaimah', 'Fujairah', 'Umm al-Quwain'] },
  'AU': { name: 'Australia', currency: 'AUD', flag: '🇦🇺', cities: ['Sydney', 'Melbourne', 'Brisbane', 'Perth', 'Adelaide', 'Canberra', 'Darwin', 'Hobart'] }
};

const PROPERTY_TYPES = [
  { id: 'riad', name: 'Riad', icon: '🏛️', regions: ['MA'] },
  { id: 'house', name: 'House', icon: '🏠', regions: ['FR','US','GB','CH','CA','AU'] },
  { id: 'apartment', name: 'Apartment', icon: '🏢', regions: ['all'] },
  { id: 'penthouse', name: 'Penthouse', icon: '🏙️', regions: ['US','GB','CH','AE'] },
  { id: 'villa', name: 'Villa', icon: '🏖️', regions: ['FR','MA','AE','AU'] },
  { id: 'loft', name: 'Loft', icon: '🏭', regions: ['US','GB','FR','CA'] },
  { id: 'studio', name: 'Studio', icon: '🛏️', regions: ['all'] },
  { id: 'duplex', name: 'Duplex', icon: '🏘️', regions: ['all'] },
  { id: 'land', name: 'Land', icon: '🌾', regions: ['all'] },
  { id: 'commercial', name: 'Commercial', icon: '🏪', regions: ['all'] },
  { id: 'office', name: 'Office', icon: '🏢', regions: ['all'] },
  { id: 'warehouse', name: 'Warehouse', icon: '🏭', regions: ['all'] }
];

const DEFAULT_TIMELINE = [
  { id: 'offer', title: 'Offer accepted', status: 'completed', date: '2024-05-15' },
  { id: 'valuation', title: 'Offer validated', status: 'completed', date: '2024-05-18' },
  { id: 'notary', title: 'Notary appointment', status: 'pending', date: '2024-05-29' },
  { id: 'conditions', title: 'Conditions period', status: 'pending', date: '2024-06-12' },
  { id: 'signature', title: 'Final signature', status: 'pending', date: '2024-06-28' },
  { id: 'handover', title: 'Handover', status: 'pending', date: '2024-06-30' }
];

const DEFAULT_CATEGORIES = [
  { id:'cat_purchase', name:"Purchase price", color:'#D4AF37', items:[
    { id:'i1', label:'Property price', amount:350000, currency:'EUR' },
    { id:'i2', label:'Notary fees', amount:38450, currency:'EUR' },
    { id:'i3', label:'Taxes', amount:21300, currency:'EUR' }
  ]},
  { id:'cat_agency', name:"Agency fees", color:'#22C55E', items:[
    { id:'i4', label:'Agent commission', amount:17500, currency:'EUR' }
  ]},
  { id:'cat_other', name:"Other costs", color:'#F59E0B', items:[
    { id:'i5', label:'Bank loan offer', amount:500, currency:'EUR' }
  ]}
];

const DEFAULT_DOCUMENTS = {
  pending: [
    { id: 'd1', name: 'Sale agreement', date: 'Due in 2 days', type: 'contract' },
    { id: 'd2', name: 'Bank loan offer', date: 'Due in 5 days', type: 'finance' }
  ],
  signed: [
    { id: 'd3', name: 'Offer letter', date: 'Signed on May 12', type: 'contract' },
    { id: 'd4', name: 'ID proof', date: 'Signed on May 13', type: 'identity' }
  ]
};

// ========== PERSISTENCE ==========
async function loadState() {
  try {
    if (window.storage) {
      const res = await window.storage.get('dealpilot_state');
      if (res && res.value) {
        state = { ...state, ...JSON.parse(res.value) };
      }
    } else {
      const stored = localStorage.getItem('dealpilot_state');
      if (stored) {
        state = { ...state, ...JSON.parse(stored) };
      }
    }
  } catch(e) {
    console.log('No existing state found - creating default project');
  }
  
  if (!state.activeProject || !state.projects[state.activeProject]) {
    if (Object.keys(state.projects).length === 0) {
      const id = createProject({
        name: 'Villa Amelkis',
        city: 'Marrakech',
        country: 'MA', 
        currency: 'MAD',
        display: 'EUR',
        propertyType: 'villa',
        budget: 425650
      }, false);
      state.activeProject = id;
    } else {
      state.activeProject = Object.keys(state.projects)[0];
    }
  }
}

async function saveState() {
  try {
    if (window.storage) {
      await window.storage.set('dealpilot_state', JSON.stringify(state));
    } else {
      localStorage.setItem('dealpilot_state', JSON.stringify(state));
    }
  } catch(e) {
    console.error('Save failed', e);
  }
}

// ========== PROJECT MANAGEMENT ==========
function createProject({name, city, country, currency, display, propertyType, budget}, persist=true) {
  const id = 'proj_' + Date.now() + '_' + Math.random().toString(36).slice(2,6);
  const countryData = COUNTRIES_DATA[country];
  const propertyData = PROPERTY_TYPES.find(p => p.id === propertyType);
  
  state.projects[id] = {
    id, name, city, country, currency, display, propertyType, budget: budget || 0,
    flag: countryData?.flag || '',
    propertyIcon: propertyData?.icon || '🏠',
    createdAt: Date.now(),
    timeline: DEFAULT_TIMELINE.map(t => ({ ...t, id: t.id + '_' + Date.now() })),
    categories: DEFAULT_CATEGORIES.map(c => ({ 
      ...c, 
      id: c.id + '_' + Date.now(),
      items: c.items.map(i => ({ ...i, id: i.id + '_' + Date.now() }))
    })),
    documents: { ...DEFAULT_DOCUMENTS }
  };
  
  if (persist) saveState();
  return id;
}

function deleteProject(id) {
  if (!confirm("Delete this project permanently?")) return;
  delete state.projects[id];
  if (state.activeProject === id) {
    state.activeProject = Object.keys(state.projects)[0] || null;
  }
  if (!state.activeProject) {
    state.activeProject = createProject({
      name:'New Project', city:'Paris', country:'FR', currency:'EUR', display:'EUR', propertyType:'apartment', budget:0
    }, false);
  }
  saveState(); render();
}

function switchProject(id) {
  if (id && state.projects[id]) {
    state.activeProject = id;
    saveState(); render();
  }
}

// ========== TAB MANAGEMENT ==========
function switchTab(tabId) {
  // Update state
  state.activeTab = tabId;
  
  // Update nav tabs
  document.querySelectorAll('.nav-tab').forEach(tab => {
    tab.classList.remove('active');
  });
  document.querySelector(`[data-tab="${tabId}"]`).classList.add('active');
  
  // Update tab content
  document.querySelectorAll('.tab-pane').forEach(pane => {
    pane.classList.remove('active');
  });
  document.getElementById(`tab-${tabId}`).classList.add('active');
  
  // Render tab-specific content
  if (tabId === 'budget') renderBudgetTab();
  else if (tabId === 'timeline') renderTimelineTab();
  else if (tabId === 'documents') renderDocumentsTab();
  else if (tabId === 'overview' || tabId === 'more') renderOverviewTab();
}

// ========== MODAL MANAGEMENT ==========
function openProjectModal(){
  renderCountryOptions();
  renderPropertyTypes();
  
  // Reset form
  document.getElementById('mpName').value = '';
  document.getElementById('mpCountry').value = '';
  document.getElementById('mpCity').innerHTML = '<option value="">Select country first</option>';
  document.getElementById('mpCity').disabled = true;
  document.getElementById('mpCurrency').innerHTML = '<option value="">—</option>';
  document.getElementById('mpDisplay').value = 'EUR';
  document.getElementById('mpBudget').value = '';
  
  // Clear property type selection
  document.querySelectorAll('.property-type').forEach(el => el.classList.remove('selected'));
  
  document.getElementById('projectModal').classList.add('show');
  setTimeout(() => document.getElementById('mpName').focus(), 100);
}

function closeProjectModal(){
  document.getElementById('projectModal').classList.remove('show');
}

function renderCountryOptions() {
  const select = document.getElementById('mpCountry');
  select.innerHTML = '<option value="">Choose country</option>' + 
    Object.entries(COUNTRIES_DATA).map(([code, data]) => 
      `<option value="${code}">${data.flag} ${data.name}</option>`
    ).join('');
}

function renderPropertyTypes() {
  const container = document.getElementById('propertyTypes');
  container.innerHTML = PROPERTY_TYPES.map(type => 
    `<div class="property-type" onclick="selectPropertyType('${type.id}')">
      <span class="property-type-icon">${type.icon}</span>
      ${type.name}
    </div>`
  ).join('');
}

function selectPropertyType(typeId) {
  document.querySelectorAll('.property-type').forEach(el => el.classList.remove('selected'));
  event.target.closest('.property-type').classList.add('selected');
  document.getElementById('propertyTypes').dataset.selected = typeId;
  
  const selectedCountry = document.getElementById('mpCountry').value;
  if (selectedCountry) {
    updatePropertyTypeVisibility(selectedCountry);
  }
}

function updateCitiesAndCurrency() {
  const countryCode = document.getElementById('mpCountry').value;
  const citySelect = document.getElementById('mpCity');
  const currencySelect = document.getElementById('mpCurrency');
  
  if (!countryCode) {
    citySelect.innerHTML = '<option value="">Select country first</option>';
    citySelect.disabled = true;
    currencySelect.innerHTML = '<option value="">—</option>';
    return;
  }
  
  const countryData = COUNTRIES_DATA[countryCode];
  
  // Update cities
  citySelect.disabled = false;
  citySelect.innerHTML = '<option value="">Choose city</option>' + 
    countryData.cities.map(city => `<option value="${city}">${city}</option>`).join('');
  
  // Update currency (auto-fill with country default)
  currencySelect.innerHTML = CURRENCIES.map(curr => 
    `<option value="${curr}" ${curr === countryData.currency ? 'selected' : ''}>${curr}</option>`
  ).join('');
  
  // Filter property types
  updatePropertyTypeVisibility(countryCode);
}

function updatePropertyTypeVisibility(countryCode) {
  document.querySelectorAll('.property-type').forEach(el => {
    const typeId = el.onclick.toString().match(/'([^']+)'/)[1];
    const type = PROPERTY_TYPES.find(t => t.id === typeId);
    
    if (type.regions.includes('all') || type.regions.includes(countryCode)) {
      el.style.display = 'block';
    } else {
      el.style.display = 'none';
      el.classList.remove('selected');
    }
  });
}

function saveProject(){
  const name = document.getElementById('mpName').value.trim();
  const country = document.getElementById('mpCountry').value;
  const city = document.getElementById('mpCity').value;
  const currency = document.getElementById('mpCurrency').value;
  const display = document.getElementById('mpDisplay').value;
  const budget = parseFloat(document.getElementById('mpBudget').value) || 0;
  const propertyType = document.getElementById('propertyTypes').dataset.selected;
  
  if (!name) { alert("Project name is required."); return; }
  if (!country) { alert("Please select a country."); return; }
  if (!city) { alert("Please select a city."); return; }
  if (!propertyType) { alert("Please choose a property type."); return; }
  
  const id = createProject({name, city, country, currency, display, propertyType, budget});
  state.activeProject = id;
  closeProjectModal();
  saveState(); render();
  showNotification('Project created successfully!');
}

// ========== EXCHANGE RATES ==========
async function fetchRates() {
  try {
    const res = await fetch('https://api.frankfurter.dev/v1/latest?base=EUR');
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const data = await res.json();
    state.rates = {
      base: 'EUR',
      rates: { EUR: 1, ...data.rates },
      fetchedAt: Date.now(),
      date: data.date
    };
    saveState();
  } catch(e) {
    // Fallback rates
    if (!state.rates) {
      state.rates = {
        base:'EUR',
        rates:{ EUR:1, USD:1.08, MAD:10.95, GBP:0.85, CHF:0.96, CAD:1.48, JPY:163, AED:3.97, AUD:1.64, SEK:11.2, NOK:11.8, DKK:7.44, PLN:4.32, CZK:24.1, HUF:389, TRY:32.5, ZAR:19.8, BRL:6.12, MXN:21.9, CNY:7.84, INR:89.5, KRW:1421, THB:37.2, IDR:17100, MYR:4.92, PHP:61.3, SGD:1.46, HKD:8.42, TWD:33.8, NZD:1.77 },
        fetchedAt: Date.now(),
        date: 'approx.'
      };
    }
  }
}

function convert(amount, fromCurrency, toCurrency) {
  if (!state.rates || !amount) return 0;
  const r = state.rates.rates;
  if (!r[fromCurrency] || !r[toCurrency]) return 0;
  const inEUR = amount / r[fromCurrency];
  return inEUR * r[toCurrency];
}

function formatMoney(amount, currency) {
  if (amount === null || amount === undefined || isNaN(amount)) amount = 0;
  const locale = currency === 'USD' ? 'en-US' : currency === 'GBP' ? 'en-GB' : 'en-US';
  try {
    return new Intl.NumberFormat(locale, {
      style:'currency', currency: currency,
      maximumFractionDigits: (currency==='JPY'||currency==='MAD'||amount>10000)?0:2
    }).format(amount);
  } catch(e) {
    return amount.toLocaleString('en-US') + ' ' + currency;
  }
}

// ========== RENDER FUNCTIONS ==========
function renderProjectSelector() {
  const select = document.getElementById('projectSelect');
  const projects = Object.values(state.projects).sort((a,b) => a.createdAt - b.createdAt);
  
  select.innerHTML = '<option value="">Choose a project...</option>' + 
    projects.map(p => 
      `<option value="${p.id}" ${p.id === state.activeProject ? 'selected' : ''}>
        ${p.propertyIcon} ${p.name} (${p.city})
      </option>`
    ).join('');
}

function renderOverviewTab() {
  const p = state.projects[state.activeProject];
  if (!p) return;

  // Update property card
  document.getElementById('propertyTitle').textContent = p.name;
  document.getElementById('propertyLocation').textContent = `${p.city}, ${COUNTRIES_DATA[p.country]?.name || p.country}`;
  
  // Calculate progress
  const completedTasks = p.timeline.filter(t => t.status === 'completed').length;
  const totalTasks = p.timeline.length;
  const progress = totalTasks ? Math.round(completedTasks / totalTasks * 100) : 0;
  
  document.getElementById('overallProgress').style.width = progress + '%';
  document.getElementById('progressPercent').textContent = progress + '%';

  // Calculate total budget
  let total = 0;
  p.categories.forEach(c => {
    c.items.forEach(i => { total += convert(i.amount, i.currency, p.display); });
  });

  document.getElementById('totalBudget').textContent = formatMoney(total, p.display);
  document.getElementById('remainingBudget').textContent = formatMoney(p.budget - total, p.display);
  
  if (state.activeTab === 'more') {
    document.getElementById('overviewBudget').textContent = formatMoney(total, p.display);
    
    // Update next task
    const nextTask = p.timeline.find(t => t.status === 'pending');
    if (nextTask) {
      document.querySelector('.task-title').textContent = nextTask.title;
      document.querySelector('.task-date').textContent = new Date(nextTask.date).toLocaleDateString('en-US', { 
        month: 'long', day: 'numeric', year: 'numeric' 
      });
    }
  }
}

function renderBudgetTab() {
  const p = state.projects[state.activeProject];
  if (!p) return;

  // Update completion status
  const totalItems = p.categories.reduce((sum, c) => sum + c.items.length, 0);
  const completedItems = p.categories.reduce((sum, c) => sum + c.items.filter(i => i.amount > 0).length, 0);
  document.getElementById('budgetCompletion').textContent = `${completedItems} / ${totalItems} completed`;

  // Update budget circle
  let total = 0;
  p.categories.forEach(c => {
    c.items.forEach(i => { total += convert(i.amount, i.currency, p.display); });
  });
  document.getElementById('budgetCircleAmount').textContent = formatMoney(total, p.display);

  // Render categories
  const container = document.getElementById('expenseCategories');
  container.innerHTML = p.categories.map(c => {
    const categoryTotal = c.items.reduce((s, i) => s + convert(i.amount, i.currency, p.display), 0);
    return `
      <div class="expense-category">
        <div class="category-header">
          <div class="category-info">
            <div class="category-dot" style="background: ${c.color}"></div>
            <span class="category-name">${escapeHtml(c.name)}</span>
          </div>
          <span class="category-amount">${formatMoney(categoryTotal, p.display)}</span>
        </div>
        <div class="expense-items">
          ${c.items.map(item => `
            <div class="expense-item">
              <span class="expense-label">${escapeHtml(item.label)}</span>
              <span class="expense-amount">${formatMoney(item.amount, item.currency)}</span>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  }).join('');
}

function renderTimelineTab() {
  const p = state.projects[state.activeProject];
  if (!p) return;

  const container = document.getElementById('timeline');
  container.innerHTML = p.timeline.map(item => `
    <div class="timeline-item">
      <div class="timeline-dot ${item.status}">
        ${item.status === 'completed' ? 
          '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20,6 9,17 4,12"/></svg>' :
          '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/></svg>'
        }
      </div>
      <div class="timeline-content">
        <div class="timeline-title">${escapeHtml(item.title)}</div>
        <div class="timeline-date">${new Date(item.date).toLocaleDateString('en-US', { 
          month: 'long', day: 'numeric', year: 'numeric' 
        })}</div>
        <span class="timeline-status ${item.status}">${item.status}</span>
      </div>
    </div>
  `).join('');
}

function renderDocumentsTab() {
  const p = state.projects[state.activeProject];
  if (!p) return;

  const container = document.getElementById('documentCategories');
  container.innerHTML = `
    <div class="document-category">
      <div class="document-category-title">Pending</div>
      ${p.documents.pending.map(doc => `
        <div class="document-item">
          <div class="document-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
              <polyline points="14,2 14,8 20,8"/>
            </svg>
          </div>
          <div class="document-info">
            <div class="document-name">${escapeHtml(doc.name)}</div>
            <div class="document-date">${escapeHtml(doc.date)}</div>
          </div>
        </div>
      `).join('')}
    </div>
    
    <div class="document-category">
      <div class="document-category-title">Signed</div>
      ${p.documents.signed.map(doc => `
        <div class="document-item">
          <div class="document-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
              <polyline points="14,2 14,8 20,8"/>
              <polyline points="20,6 9,17 4,12"/>
            </svg>
          </div>
          <div class="document-info">
            <div class="document-name">${escapeHtml(doc.name)}</div>
            <div class="document-date">${escapeHtml(doc.date)}</div>
          </div>
        </div>
      `).join('')}
    </div>
  `;
}

function render() {
  renderProjectSelector();
  renderOverviewTab();
}

// ========== HELPER FUNCTIONS ==========
function escapeHtml(s) {
  return String(s || '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

function showNotification(message) {
  const notification = document.getElementById('notification');
  notification.querySelector('.notification-text').textContent = message;
  notification.classList.add('show');
  setTimeout(() => notification.classList.remove('show'), 3000);
}

// ========== CATEGORY MANAGEMENT ==========
function addCategory() {
  const p = state.projects[state.activeProject];
  const color = CATEGORY_COLORS[p.categories.length % CATEGORY_COLORS.length];
  p.categories.push({
    id: 'cat_' + Date.now(),
    name: 'New Category',
    color,
    items: []
  });
  saveState(); renderBudgetTab();
}

// ========== TIMELINE MANAGEMENT ==========
function addTimelineItem() {
  showNotification('Calendar integration coming soon!');
}

// ========== DOCUMENT MANAGEMENT ==========
function uploadDocument() {
  showNotification('Document upload feature coming soon!');
}

// ========== EXPORT FUNCTIONS ==========
function exportPDF() {
  const p = state.projects[state.activeProject];
  if (!p) return;

  let total = 0;
  p.categories.forEach(c => {
    c.items.forEach(i => { total += convert(i.amount, i.currency, p.display); });
  });

  const propertyData = PROPERTY_TYPES.find(pt => pt.id === p.propertyType);
  const propertyName = propertyData ? propertyData.name : 'Property';

  const win = window.open('', '_blank');
  const html = `
    <!DOCTYPE html><html><head><meta charset="UTF-8"><title>DealPilot — ${escapeHtml(p.name)}</title>
    <style>
      body{font-family:'Poppins',sans-serif;color:#081320;padding:48px;max-width:900px;margin:0 auto;background:#f9f9f9}
      h1{font-weight:700;font-size:32px;margin:0 0 8px;color:#081320}
      .tagline{font-size:12px;color:#687085;text-transform:uppercase;letter-spacing:1px;margin-bottom:32px}
      .logo{display:flex;align-items:center;gap:16px;margin-bottom:32px}
      .logo svg{width:40px;height:40px;color:#081320}
      .brand-name{font-size:24px;font-weight:700}.accent{color:#D4AF37}
      .total-box{border:2px solid #D4AF37;background:#fff;padding:24px;margin:32px 0;text-align:center}
      .total-amount{font-size:36px;font-weight:700;color:#D4AF37;margin-bottom:8px}
      h2{font-size:20px;margin:32px 0 16px;color:#081320;border-bottom:2px solid #D4AF37;padding-bottom:8px}
      table{width:100%;border-collapse:collapse;margin-bottom:32px}
      th,td{text-align:left;padding:12px;border-bottom:1px solid #E6E6EF}
      th{background:#081320;color:white;font-weight:600}
      .timeline-item{display:flex;align-items:center;padding:12px 0;border-bottom:1px solid #E6E6EF}
      .timeline-status{padding:4px 12px;border-radius:20px;font-size:11px;font-weight:600;text-transform:uppercase}
      .completed{background:#22C55E;color:white}.pending{background:#F59E0B;color:white}
      @media print{body{background:white;padding:20px}}
    </style></head><body>
    <div class="logo">
      <svg viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg">
        <path d="M8 12h14a6 6 0 0 1 6 6v10a6 6 0 0 1-6 6H8V12z" fill="currentColor"/>
        <path d="M14 18h8l-3.2 3.2h-1.6L14 18z" fill="#D4AF37"/>
      </svg>
      <div>
        <div class="brand-name">Deal<span class="accent">Pilot</span></div>
        <div class="tagline">Every step. Total control. Complete peace of mind.</div>
      </div>
    </div>

    <h1>${p.propertyIcon} ${escapeHtml(p.name)}</h1>
    <p><strong>Location:</strong> ${escapeHtml(p.city)}, ${COUNTRIES_DATA[p.country]?.name || p.country}</p>
    <p><strong>Type:</strong> ${propertyName}</p>
    <p><strong>Currency:</strong> ${p.currency} → ${p.display}</p>
    <p><strong>Generated:</strong> ${new Date().toLocaleDateString('en-US', {
      year: 'numeric', month: 'long', day: 'numeric'
    })}</p>

    <div class="total-box">
      <div class="total-amount">${formatMoney(total, p.display)}</div>
      <div>Total Project Budget</div>
    </div>

    <h2>Timeline</h2>
    ${p.timeline.map(t => `
      <div class="timeline-item">
        <span class="timeline-status ${t.status}">${t.status}</span>
        <span style="margin-left:16px;flex:1">${escapeHtml(t.title)}</span>
        <span style="color:#687085;font-size:14px">${new Date(t.date).toLocaleDateString('en-US', {
          month: 'short', day: 'numeric', year: 'numeric'
        })}</span>
      </div>
    `).join('')}

    <h2>Budget Breakdown</h2>
    <table>
      <thead><tr>
        <th>Category</th><th>Item</th><th>Amount</th><th>Currency</th><th>In ${p.display}</th>
      </tr></thead>
      <tbody>
        ${p.categories.map(c => 
          c.items.map(i => `
            <tr>
              <td style="color:${c.color};font-weight:600">${escapeHtml(c.name)}</td>
              <td>${escapeHtml(i.label)}</td>
              <td style="text-align:right">${(i.amount||0).toLocaleString('en-US')}</td>
              <td>${i.currency}</td>
              <td style="text-align:right;font-weight:600">${formatMoney(convert(i.amount, i.currency, p.display), p.display)}</td>
            </tr>
          `).join('')
        ).join('')}
        <tr style="border-top:2px solid #D4AF37;background:#fff5e6">
          <td colspan="4" style="font-weight:700">TOTAL</td>
          <td style="text-align:right;font-weight:700;font-size:18px;color:#D4AF37">${formatMoney(total, p.display)}</td>
        </tr>
      </tbody>
    </table>

    <div style="margin-top:48px;text-align:center;color:#687085;font-size:12px">
      Generated by DealPilot — Your real estate acquisition partner
    </div>

    <script>window.onload = () => { setTimeout(() => window.print(), 300); }<\/script>
    </body></html>
  `;
  win.document.write(html);
  win.document.close();
}

function exportExcel() {
  const p = state.projects[state.activeProject];
  if (!p) return;

  let csv = '\uFEFF'; // BOM for Excel UTF-8
  csv += `Project Name;${p.name}\n`;
  csv += `Location;${p.city}, ${COUNTRIES_DATA[p.country]?.name || p.country}\n`;
  csv += `Property Type;${PROPERTY_TYPES.find(pt => pt.id === p.propertyType)?.name || p.propertyType}\n`;
  csv += `Local Currency;${p.currency}\n`;
  csv += `Display Currency;${p.display}\n`;
  csv += `Export Date;${new Date().toLocaleDateString('en-US')}\n\n`;

  csv += `=== TIMELINE ===\n`;
  csv += `Status;Task;Date\n`;
  p.timeline.forEach(t => {
    csv += `${t.status};"${t.title.replace(/"/g,'""')}";${new Date(t.date).toLocaleDateString('en-US')}\n`;
  });

  csv += `\n=== BUDGET BREAKDOWN ===\n`;
  csv += `Category;Item;Amount;Currency;In ${p.display}\n`;

  let grandTotal = 0;
  p.categories.forEach(c => {
    let catTotal = 0;
    c.items.forEach(i => {
      const converted = convert(i.amount, i.currency, p.display);
      catTotal += converted;
      csv += `"${c.name.replace(/"/g,'""')}";"${i.label.replace(/"/g,'""')}";${(i.amount||0).toString().replace('.',',')};${i.currency};${converted.toFixed(2).replace('.',',')}\n`;
    });
    csv += `"${c.name.replace(/"/g,'""')}";SUBTOTAL;;;${catTotal.toFixed(2).replace('.',',')}\n`;
    grandTotal += catTotal;
  });
  csv += `\n;;TOTAL;${p.display};${grandTotal.toFixed(2).replace('.',',')}\n`;

  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  const safeName = p.name.replace(/[^a-z0-9]/gi, '_').toLowerCase();
  a.href = url;
  a.download = `dealpilot_${safeName}_${new Date().toISOString().slice(0,10)}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

// ========== EVENT BINDINGS ==========
// Close modal on background click
document.addEventListener('click', (e) => {
  if (e.target.id === 'projectModal') closeProjectModal();
});

// ========== INITIALIZATION ==========
(async () => {
  await loadState();
  await fetchRates();
  render();
})();